import acm.program.*;
import java.util.*;

public class Problem1c extends ConsoleProgram {
    public void run() {
        HashMap<String, String> map = new HashMap<String, String>();
        String[] items = {"The", "quick", "brown", "fox", "jumped", "over", "the", "lazy", "black", "dog"};
        for (int i = 0; i < items.length - 1; i+=2) {
            map.put(items[i], items[i+1]);
        }
        
        printValues(map);
    }

    /* Answer for 1C */
    // don't worry about importing packages
    // print out all values in the given hashmap.
    // you are guaranteed that each value in the map is unique
    // thus you don't need to worry about duplicates.
    private void printValues(HashMap<String, String> map) {
        for (String key : map.keySet()) {
            println(map.get(key));
        }
    }
}