/*
 * This question corresponds to a written response and is not intended to be run.
 */

A)
i: 0, int
ii: "one two 3" , String
iii: 1, int
iv: 7, int
v: true, boolean

B)
Output:
Two squares of size 100x100 are added to the screen. 
They have different memory addresses so neither is filled
One square is at (300,300).
The other square is at (0,0) 


C)
public void run() {
    for (int i=3; i <= 99; i+=3){
        println(i);
    }
}