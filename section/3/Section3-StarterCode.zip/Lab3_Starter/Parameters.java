/*
 * File: Problem1.java
 * -------------------
 * Copy the code into the following functions to test whether your answers are
 * correct
 */

import acm.program.*;

public class Parameters extends ConsoleProgram {

	public void run() {
		// TODO
	}
}
