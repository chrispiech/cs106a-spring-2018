/*
 * File: MakeBoxes.java
 * By Julia Daniel
 * --------------------
 * This program draws three boxes:
 *  - one 20 px x 20 px with upper left corner at (0, 0)
 *  - one 40 px x 40 px with upper left corner at (100, 100)
 *  - one 60 px x 60 px with upper left corner at (200, 200)
 */

import java.awt.event.MouseEvent;

import acm.program.*;
import acm.graphics.*;
import acm.util.*;

public class MakeBoxes extends GraphicsProgram {

	public void run() {
		for (int i = 0; i < 3; i++) {
			GRect newBox = createBox(i + 1);
			add(newBox, i * 100, i * 100);
		}
	}

	private GRect createBox(int i) {
		GRect box = new GRect(i * 20, i * 20);
		i += 5;
		return box;
	}
}
