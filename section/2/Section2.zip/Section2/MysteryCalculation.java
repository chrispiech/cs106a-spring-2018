 /*
 * File: MysteryCalculation.java
 * -----------------------------
 * This program reads in a line equation from a user and, 
 * for every x entered until -1, outputs the corresponding y value.
 */

import acm.program.*;

public class MysteryCalculation extends ConsoleProgram {
	
	/* Defines the term the user enters to stop the program */
	private static final int SENTINEL = -1;
	
	public void run() {
		println("This program calculates y coordinates for a line.");
		int a = readInt("Enter a value for a: ");
		int b = readInt("Enter a value for b: ");

		int x = readInt("Enter a value for x: ");
		while (x != SENTINEL) {
			int y = a * x + b;
			println("Result for x = " + x + " is " + y);
			x = readInt("Enter a value for x: ");
		}
	}
}