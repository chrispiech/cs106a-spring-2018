
import acm.graphics.*;
import acm.program.*;
import acm.util.RandomGenerator;

public class MPedigree extends ConsoleProgram {

	private static final int N_BOXES = 100;
	private static final int ID_DIGITS = 4;
	private static final int RAND_DIGITS = 6;
	
	private RandomGenerator rg = new RandomGenerator();
	
	public void run() {
		setFont("Courier-24");
		for(int i = 0; i < N_BOXES; i++) {
			// do something....
		}
	}

	/**
	 * Makes a code to put on a pill box that is both (1) unique and
	 * (2) unguessable. The code will always be of length 10.
	 */
	private String makeCode(int uniqueId) {
		// todo...
		return "";
	}

}
