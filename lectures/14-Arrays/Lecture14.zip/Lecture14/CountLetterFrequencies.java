/*
 * File: CountLetterFrequencies.java
 * ---------------------------------
 * This program counts the frequency of letters in user-entered text.
 */

import acm.program.*;

/**
 * This program creates a table of the letter frequencies in a 
 * paragraph of input text terminated by a blank line.
 */
public class CountLetterFrequencies extends ConsoleProgram {


	public void run() {
		println("This program counts letter frequencies.");
		
		// make a frequency histogram which is initially empty
		initFrequencyTable();
		String line = readLine("Enter a line: ");
		
		// make this histogram of characters in the string
		countLetterFrequencies(line);
		
		// print out the histogram
		printFrequencyTable();
	}
	
	/* Counts the letter frequencies in a line of text */
	private void countLetterFrequencies(String line) {
		// TODO: this is your job.
	}

	/* Initializes the frequency table to contain zeros */
	private void initFrequencyTable() {
		// TODO
	}

	/* Displays the frequency table */
	private void printFrequencyTable() {
		// TODO
	}


}
