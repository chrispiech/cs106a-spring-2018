import java.awt.Color;

import acm.graphics.GOval;
import acm.util.RandomGenerator;

public class Ball {
	
	private static final int BALL_SIZE = 20;
	
	// 1: what variables make up a ball?
	private GOval circle;
	private double dx;
	private double dy;
	
	// Constructor: makes a new ball. Needs to know the screen
	// width and height
	public Ball(int screenWidth, int screenHeight) {
		RandomGenerator rg = RandomGenerator.getInstance();
		double x = rg.nextInt(screenWidth - BALL_SIZE);
		double y = rg.nextInt(screenHeight - BALL_SIZE);
		
		// make the ball's circle
		this.circle = new GOval(x, y, BALL_SIZE, BALL_SIZE);
		this.circle.setFilled(true);
		this.circle.setColor(Color.BLUE);
		
		// gets a random dx and a random dy
		this.dx = getRandomSpeed();
		this.dy = getRandomSpeed();
	}
	
	// Public Method: Get GOval
	// Returns the ball's GOval
	public GOval getGOval() {
		return null;
	}
	
	// Public Method: Heartbeat
	// Animates one heartbeat
	public void heartbeat(int screenWidth, int screenHeight) {
		
	}
	
	/**************************************************
	 *           PRIVATE METHODS                      *
	 **************************************************/
	
	private boolean hitRightWall(int screenWidth) {
		return circle.getX() > screenWidth - BALL_SIZE;
	}
	
	private boolean hitLeftWall() {
		return circle.getX() < 0;
	}
	
	private boolean hitBottomWall(int screenHeight) {
		return circle.getY() > screenHeight - BALL_SIZE;
	}
	
	private boolean hitTopWall() {
		return circle.getY() < 0;
	}
	
	private double getRandomSpeed() {
		RandomGenerator rg = RandomGenerator.getInstance();
		double speed = rg.nextDouble(1,3);
		if(rg.nextBoolean()) {
			speed *= -1;
		}
		return speed;
	}
}
