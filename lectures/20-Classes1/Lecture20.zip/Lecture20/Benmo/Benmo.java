
import java.awt.event.ActionEvent;
import java.util.*;

import javax.swing.*;

import acm.program.*;

public class Benmo extends GraphicsProgram {

	public void run() {
		
		// TODO: write Benmo.
		
	}

	

}