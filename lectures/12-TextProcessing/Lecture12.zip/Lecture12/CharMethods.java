
import acm.program.*;
import java.lang.Character;

public class CharMethods extends ConsoleProgram {

	public void run() {
		setFont("Courier-24");

		while(true) {
			String str = readLine("Line: ");

			char ch = str.charAt(0);
			println("Original first char: " + ch);

			ch = Character.toUpperCase(ch);
			println("Uppercase first char: " + ch);

			if(Character.isLetter(ch)) {
				println("It’s a letter!");
			} else {
				println("It's not a letter...");
			}
			println("");
		}
	}


}
