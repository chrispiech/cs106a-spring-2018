/*
 * File: PythagoreanTheorem.java
 * Name: 
 * Section Leader: 
 * -----------------------------
 * This file is the starter file for the PythagoreanTheorem problem.
 */

import acm.graphics.*;
import acm.program.*;

public class Demo extends ConsoleProgram {

	public void run() {
		String example = "Hi mom";
		
		// example of length method
		int length = example.length();
		println(length); // prints 6
		
		// example of getCharAt
		char firstLetter = example.charAt(0);
		println(firstLetter); // prints 'H'
		
		// example of loop that prints letters one-by-one
		for(int i = 0; i < example.length(); i++) {
			char ch = example.charAt(i);
			println(ch);
		}
		
	}

	

}
