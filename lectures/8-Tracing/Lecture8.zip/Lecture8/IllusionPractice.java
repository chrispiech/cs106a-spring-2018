/*
 * File: CheckerBoard.java
 * -----------------
 * Draws a checkerboard with alternating black and white tiles.
 */

import acm.graphics.*;
import acm.program.*;
import java.awt.*;

public class IllusionPractice extends GraphicsProgram {	

	private static final int UNIT_SCALE = 10;

	/* The size of a single square on the board */
	private static final int SQUARE_SIZE = 50;
	
	/* Number of rows */
	private static final int NROWS = 9;
	
	/* Number of cols */
	private static final int NCOLS = 9;

	public void run() {
		// draw many rows
		for(int rowIndex = 0; rowIndex < NROWS; rowIndex++) {
			// draw a single row
			drawRow(rowIndex);
		}
	}

	private void drawRow(int rowIndex) {
		double rowXOffset = calculateRowXOffset(rowIndex);
		// draw a row of squares
		for(int colIndex = 0; colIndex < NCOLS; colIndex++) {
			// draw a single square
			drawSquare(rowIndex, colIndex, rowXOffset);
		}
	}

	private double calculateRowXOffset(int row) {
		// first calculate
		int nUnitsRight = row % 4;
		return nUnitsRight * UNIT_SCALE;
	}

	private void drawSquare(int row, int col, double rowXOffset) {
		double x = rowXOffset + col * SQUARE_SIZE;
		double y = row * SQUARE_SIZE;
		GRect square = new GRect(SQUARE_SIZE, SQUARE_SIZE);
		// fill if your col is even
		square.setFilled(col % 2 == 0);
		add(square, x, y);
	}
}
