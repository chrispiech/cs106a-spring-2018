/*
 * File: HelloWorld.java
 * Name: 
 * Section Leader: 
 * -----------------------------
 * This file is the starter file for the PythagoreanTheorem problem.
 */

// Import the console program code
import acm.program.*;

// Just like in Karel, but instead of KarelProgram,
// this is a ConsoleProgram
public class HelloWorld extends ConsoleProgram {
	
	// The program starts here
	public void run() {
		println("Hello, world");
	}
	
}
